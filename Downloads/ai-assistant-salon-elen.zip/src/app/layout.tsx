// src/app/layout.tsx
import type { Metadata } from "next";
import { cookies } from "next/headers";
import { Playfair_Display, Cormorant_Garamond } from "next/font/google";
import "./globals.css";

import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import Providers from "@/app/providers";

import { I18nProvider } from "@/i18n/I18nProvider";
import { LocaleProvider } from "@/i18n/LocaleContext";
import { DEFAULT_LOCALE, LOCALES, type Locale } from "@/i18n/locales";
import ChatWidget from "@/components/ai/ChatWidget";

// Fonts
const playfair = Playfair_Display({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
  variable: "--font-playfair",
});

const cormorant = Cormorant_Garamond({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600"],
  display: "swap",
  variable: "--font-cormorant",
});

// Base metadata — pages override title/description/canonical via generateMetadata
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://permanent-halle.de"),
  title: {
    default: "Salon Elen — Kosmetiksalon in Halle (Saale)",
    template: "%s",
  },
  description: "Professioneller Kosmetiksalon in Halle (Saale)",
  icons: {
    icon: [
      { url: "/favicon.ico?v=20260223icons1", sizes: "any" },
      { url: "/icon-192x192.png?v=20260223icons1", type: "image/png", sizes: "192x192" },
      { url: "/icon-512x512.png?v=20260223icons1", type: "image/png", sizes: "512x512" },
    ],
    apple: [{ url: "/apple-touch-icon.png?v=20260223icons1", sizes: "180x180", type: "image/png" }],
    shortcut: [{ url: "/favicon.ico?v=20260223icons1" }],
  },
  manifest: "/site.webmanifest?v=20260223icons1",
  robots: {
    index: true,
    follow: true,
    "max-image-preview": "large",
    "max-snippet": -1,
    "max-video-preview": -1,
  },
  openGraph: { images: ["/images/hero.webp"] },
  twitter: { images: ["/images/hero.webp"] },
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cookieStore = await cookies();
  const cookieLocale = cookieStore.get("locale")?.value as Locale | undefined;

  const initialLocale: Locale =
    cookieLocale && LOCALES.includes(cookieLocale) ? cookieLocale : DEFAULT_LOCALE;

  return (
    <html lang={initialLocale} suppressHydrationWarning>
      <body
        className={`
          ${playfair.variable}
          ${cormorant.variable}
          bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100 antialiased
        `}
      >
        <Providers>
          <I18nProvider initialLocale={initialLocale}>
            <LocaleProvider initialLocale={initialLocale}>
              <SiteHeader />
              <main>{children}</main>
              <SiteFooter />
              <ChatWidget locale={initialLocale} />
            </LocaleProvider>
          </I18nProvider>
        </Providers>
      </body>
    </html>
  );
}




//--------работал до 14.02.26 исправляем для SEO
// // src/app/layout.tsx
// import type { Metadata } from "next";
// import { cookies } from "next/headers";
// import { Playfair_Display, Cormorant_Garamond } from "next/font/google";
// import "./globals.css";

// import SiteHeader from "@/components/site-header";
// import SiteFooter from "@/components/site-footer";
// import Providers from "@/app/providers";

// import { I18nProvider } from "@/i18n/I18nProvider";
// import { LocaleProvider } from "@/i18n/LocaleContext";
// import { DEFAULT_LOCALE, LOCALES, type Locale } from "@/i18n/locales";

// // Fonts
// const playfair = Playfair_Display({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600", "700"],
//   display: "swap",
//   variable: "--font-playfair",
// });

// const cormorant = Cormorant_Garamond({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600"],
//   display: "swap",
//   variable: "--font-cormorant",
// });

// // Важно: НЕ ставим title.template, чтобы не было "… — Salon Elen — Salon Elen"
// export const metadata: Metadata = {
//   metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://permanent-halle.de"),
//   title: "Salon Elen",
//   description: "Kosmetiksalon in Halle – Leistungen, Preise, Kontakt",
//   openGraph: { images: ["/images/hero.webp"] },
//   twitter: { images: ["/images/hero.webp"] },
// };

// export default async function RootLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   const cookieStore = await cookies();
//   const cookieLocale = cookieStore.get("locale")?.value as Locale | undefined;

//   const initialLocale: Locale =
//     cookieLocale && LOCALES.includes(cookieLocale) ? cookieLocale : DEFAULT_LOCALE;

//   return (
//     <html lang={initialLocale} suppressHydrationWarning>
//       <body
//         className={`
//           ${playfair.variable}
//           ${cormorant.variable}
//           bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100 antialiased
//         `}
//       >
//         <Providers>
//           <I18nProvider initialLocale={initialLocale}>
//             <LocaleProvider initialLocale={initialLocale}>
//               <SiteHeader />
//               <main>{children}</main>
//               <SiteFooter />
//             </LocaleProvider>
//           </I18nProvider>
//         </Providers>
//       </body>
//     </html>
//   );
// }



//--------без хоме сео тагс----
// // src/app/layout.tsx
// import type { Metadata } from "next";
// import { cookies } from "next/headers";
// import { Playfair_Display, Cormorant_Garamond } from "next/font/google";
// import "./globals.css";

// import SiteHeader from "@/components/site-header";
// import SiteFooter from "@/components/site-footer";
// import Providers from "@/app/providers";
// import HomeSeoTags from "@/components/home-seo-tags";

// import { I18nProvider } from "@/i18n/I18nProvider";
// import { LocaleProvider } from "@/i18n/LocaleContext";
// import { DEFAULT_LOCALE, LOCALES, type Locale } from "@/i18n/locales";

// // Fonts
// const playfair = Playfair_Display({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600", "700"],
//   display: "swap",
//   variable: "--font-playfair",
// });

// const cormorant = Cormorant_Garamond({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600"],
//   display: "swap",
//   variable: "--font-cormorant",
// });

// // Важно: НЕ ставим title.template, чтобы не было "… — Salon Elen — Salon Elen"
// export const metadata: Metadata = {
//   metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://permanent-halle.de"),
//   title: "Salon Elen",
//   description: "Kosmetiksalon in Halle – Leistungen, Preise, Kontakt",
//   openGraph: { images: ["/images/hero.webp"] },
//   twitter: { images: ["/images/hero.webp"] },
// };

// export default async function RootLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   const cookieStore = await cookies();
//   const cookieLocale = cookieStore.get("locale")?.value as Locale | undefined;

//   const initialLocale: Locale =
//     cookieLocale && LOCALES.includes(cookieLocale) ? cookieLocale : DEFAULT_LOCALE;

//   return (
//     <html lang={initialLocale} suppressHydrationWarning>
//       <body
//         className={`
//           ${playfair.variable}
//           ${cormorant.variable}
//           bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100 antialiased
//         `}
//       >
//         <Providers>
//           <HomeSeoTags />
//           <I18nProvider initialLocale={initialLocale}>
//             <LocaleProvider initialLocale={initialLocale}>
//               <SiteHeader />
//               <main>{children}</main>
//               <SiteFooter />
//             </LocaleProvider>
//           </I18nProvider>
//         </Providers>
//       </body>
//     </html>
//   );
// }



//---------версия клода-----
// // src/app/layout.tsx
// import type { Metadata } from "next";
// import { cookies } from "next/headers";
// import { Playfair_Display, Cormorant_Garamond } from "next/font/google";
// import "./globals.css";

// import SiteHeader from "@/components/site-header";
// import SiteFooter from "@/components/site-footer";
// import Providers from "@/app/providers";

// import { I18nProvider } from "@/i18n/I18nProvider";
// import { LocaleProvider } from "@/i18n/LocaleContext";
// import { DEFAULT_LOCALE, LOCALES, type Locale } from "@/i18n/locales";

// // Fonts
// const playfair = Playfair_Display({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600", "700"],
//   display: "swap",
//   variable: "--font-playfair",
// });

// const cormorant = Cormorant_Garamond({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600"],
//   display: "swap",
//   variable: "--font-cormorant",
// });

// // Важно: НЕ ставим title.template, чтобы не было "… — Salon Elen — Salon Elen"
// export const metadata: Metadata = {
//   metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://permanent-halle.de"),
//   title: "Salon Elen",
//   description: "Kosmetiksalon in Halle – Leistungen, Preise, Kontakt",
//   openGraph: { images: ["/images/hero.webp"] },
//   twitter: { images: ["/images/hero.webp"] },
// };

// export default async function RootLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   const cookieStore = await cookies();
//   const cookieLocale = cookieStore.get("locale")?.value as Locale | undefined;

//   const initialLocale: Locale =
//     cookieLocale && LOCALES.includes(cookieLocale) ? cookieLocale : DEFAULT_LOCALE;

//   return (
//     <html lang={initialLocale} suppressHydrationWarning>
//       <body
//         className={`
//           ${playfair.variable}
//           ${cormorant.variable}
//           bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100 antialiased
//         `}
//       >
//         <Providers>
//           <I18nProvider initialLocale={initialLocale}>
//             <LocaleProvider initialLocale={initialLocale}>
//               <SiteHeader />
//               <main>{children}</main>
//               <SiteFooter />
//             </LocaleProvider>
//           </I18nProvider>
//         </Providers>
//       </body>
//     </html>
//   );
// }





// // src/app/layout.tsx
// import type { Metadata } from "next";
// import { cookies } from "next/headers";
// import { Playfair_Display, Cormorant_Garamond } from "next/font/google";
// import "./globals.css";

// import SiteHeader from "@/components/site-header";
// import SiteFooter from "@/components/site-footer";
// import Providers from "@/app/providers";

// import { I18nProvider } from "@/i18n/I18nProvider";
// import { LocaleProvider } from "@/i18n/LocaleContext";
// import { DEFAULT_LOCALE, LOCALES, type Locale } from "@/i18n/locales";

// // ====== Fonts (non-blocking) ======
// const playfair = Playfair_Display({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600", "700"],
//   display: "swap",
//   variable: "--font-playfair",
// });

// const cormorant = Cormorant_Garamond({
//   subsets: ["latin", "cyrillic"],
//   weight: ["400", "500", "600"],
//   display: "swap",
//   variable: "--font-cormorant",
// });

// // ✅ Только базовая metadata.
// // ❗ canonical/hreflang задаём на уровне страниц (generateMetadata + alternates).
// export const metadata: Metadata = {
//   metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://permanent-halle.de"),
//   title: {
//     default: "Salon Elen",
//     template: "%s — Salon Elen",
//   },
//   description: "Kosmetiksalon in Halle – Leistungen, Preise, Kontakt",
//   openGraph: { images: ["/images/hero.webp"] },
//   twitter: { images: ["/images/hero.webp"] },
// };

// type RootLayoutProps = {
//   children: React.ReactNode;
// };

// export default async function RootLayout({ children }: RootLayoutProps) {
//   const cookieStore = await cookies();
//   const cookieLocale = cookieStore.get("locale")?.value as Locale | undefined;

//   const initialLocale: Locale =
//     cookieLocale && LOCALES.includes(cookieLocale) ? cookieLocale : DEFAULT_LOCALE;

//   return (
//     <html lang={initialLocale} suppressHydrationWarning>
//       <body
//         className={`
//           ${playfair.variable}
//           ${cormorant.variable}
//           bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100 antialiased
//         `}
//       >
//         <Providers>
//           <I18nProvider initialLocale={initialLocale}>
//             <LocaleProvider initialLocale={initialLocale}>
//               <SiteHeader />
//               <main>{children}</main>
//               <SiteFooter />
//             </LocaleProvider>
//           </I18nProvider>
//         </Providers>
//       </body>
//     </html>
//   );
// }
