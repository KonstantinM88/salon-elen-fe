-- AlterTable
ALTER TABLE "Master" ADD COLUMN     "avatarUrl" TEXT;
