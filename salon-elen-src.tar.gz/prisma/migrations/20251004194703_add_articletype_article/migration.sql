-- AlterEnum
ALTER TYPE "public"."ArticleType" ADD VALUE 'ARTICLE';
