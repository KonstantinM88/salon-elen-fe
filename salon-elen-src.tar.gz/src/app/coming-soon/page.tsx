export default function ComingSoon() {
    return (
      <main className="container py-16">
        <h1 className="text-3xl font-semibold">Скоро будет!</h1>
        <p className="mt-3 text-gray-600 dark:text-gray-300">
          Раздел в разработке. Возвращайтесь позже.
        </p>
      </main>
    );
  }
  