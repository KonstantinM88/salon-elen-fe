// Единая зона салона: меняйте при необходимости
export const APP_TIMEZONE = process.env.APP_TIMEZONE || 'Europe/Berlin';
